import { Routes } from '@angular/router';
import { RazorpayComponent } from './razor-pay.component';


export const RazorpayRoutes: Routes = [
  {
    path: "",
    component: RazorpayComponent,
  }
];